import React from "react";
export const TotalPriceContext = React.createContext(null);
export const BurgerIngredientsContext = React.createContext(null);
