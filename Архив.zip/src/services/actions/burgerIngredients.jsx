
export const TAB_SWITCH = 'TAB_SWITCH';
export const TOGGLE_MODAL = 'TOGGLE_MODAL';
